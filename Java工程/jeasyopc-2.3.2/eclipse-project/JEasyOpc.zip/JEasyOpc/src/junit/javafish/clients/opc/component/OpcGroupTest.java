package javafish.clients.opc.component;

import junit.framework.TestCase;

public class OpcGroupTest extends TestCase {

  protected void setUp() throws Exception {
    super.setUp();
  }

  public void testIsActive() {
    fail("Not yet implemented");
  }

  public void testSetActive() {
    fail("Not yet implemented");
  }

  public void testGetItems() {
    fail("Not yet implemented");
  }

  public void testGetItemsAsArray() {
    fail("Not yet implemented");
  }

  public void testAddItem() {
    fail("Not yet implemented");
  }

  public void testRemoveItem() {
    fail("Not yet implemented");
  }

  public void testGetUpdateRate() {
    fail("Not yet implemented");
  }

  public void testSetUpdateRate() {
    fail("Not yet implemented");
  }

  public void testGetClientHandle() {
    fail("Not yet implemented");
  }

  public void testGetGroupName() {
    fail("Not yet implemented");
  }

  public void testGetPercentDeadBand() {
    fail("Not yet implemented");
  }

  public void testGetItemByClientHandle() {
    fail("Not yet implemented");
  }

  public void testClone() {
    fail("Not yet implemented");
  }

}
